import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-white">
      <nav className="flex justify-between items-center px-8 py-4 border-b border-slate-700">
        <div className="text-2xl font-bold text-blue-400">CollegeLink</div>
        <div className="flex gap-4">
          <Link href="/login">
            <Button variant="ghost" className="text-white hover:text-blue-400">
              Login
            </Button>
          </Link>
          <Link href="/signup">
            <Button className="bg-blue-600 hover:bg-blue-700">Sign Up</Button>
          </Link>
        </div>
      </nav>

      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-80px)] text-center">
        <h1 className="text-6xl font-bold mb-6 text-balance">Network with College Students</h1>
        <p className="text-xl text-slate-300 mb-8 max-w-2xl">
          Share projects, collaborate on hackathons, discover opportunities, and build your professional network all in
          one place.
        </p>
        <div className="flex gap-4">
          <Link href="/signup">
            <Button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg">Get Started</Button>
          </Link>
          <Link href="/login">
            <Button variant="outline" className="border-slate-500 text-white px-8 py-6 text-lg bg-transparent">
              Sign In
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
