"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { PostCreator } from "@/components/feed/post-creator"
import { PostCard } from "@/components/feed/post-card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function FeedPage() {
  const router = useRouter()
  const [posts, setPosts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    fetchPosts()
  }, [])

  const fetchPosts = async () => {
    try {
      const token = localStorage.getItem("token")
      if (!token) {
        router.push("/login")
        return
      }

      const res = await fetch("/api/posts", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (!res.ok) {
        if (res.status === 401) {
          router.push("/login")
          return
        }
        throw new Error("Failed to fetch posts")
      }

      const data = await res.json()
      setPosts(data.posts || [])
    } catch (err) {
      console.error("Error fetching posts:", err)
      setError("Failed to load posts")
    } finally {
      setLoading(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("token")
    localStorage.removeItem("user")
    router.push("/login")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800">
      <nav className="sticky top-0 z-50 bg-slate-900/95 backdrop-blur border-b border-slate-700">
        <div className="max-w-2xl mx-auto flex justify-between items-center px-6 py-4">
          <div className="text-2xl font-bold text-blue-400">CollegeLink</div>
          <div className="flex gap-4 items-center">
            <Link href="/profile">
              <Button variant="ghost" className="text-slate-300 hover:text-white">
                Profile
              </Button>
            </Link>
            <Link href="/projects">
              <Button variant="ghost" className="text-slate-300 hover:text-white">
                Projects
              </Button>
            </Link>
            <Link href="/events">
              <Button variant="ghost" className="text-slate-300 hover:text-white">
                Events
              </Button>
            </Link>
            <Link href="/hackathon">
              <Button variant="ghost" className="text-slate-300 hover:text-white">
                Hackathon
              </Button>
            </Link>
            <Button onClick={handleLogout} variant="outline" className="border-slate-600 text-slate-300 bg-transparent">
              Logout
            </Button>
          </div>
        </div>
      </nav>

      <div className="max-w-2xl mx-auto p-6">
        <PostCreator onPostCreated={fetchPosts} />

        {error && <div className="p-4 bg-red-900/20 border border-red-700 text-red-400 rounded mb-6">{error}</div>}

        {loading ? (
          <div className="text-center text-slate-400">Loading posts...</div>
        ) : posts.length === 0 ? (
          <div className="text-center text-slate-400">No posts yet. Be the first to share something!</div>
        ) : (
          <div>
            {posts.map((post) => (
              <PostCard key={post._id} post={post} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
