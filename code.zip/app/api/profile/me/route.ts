import { connectToDatabase } from "@/lib/mongodb"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(req: NextRequest) {
  try {
    const token = req.headers.get("Authorization")?.split(" ")[1]

    if (!token) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    // In production, verify the token and extract user ID
    // For now, return a placeholder

    const { db } = await connectToDatabase()
    const usersCollection = db.collection("users")

    // Find the most recent user (this is a placeholder - use proper token verification)
    const user = await usersCollection.findOne({})

    if (!user) {
      return NextResponse.json({ message: "User not found" }, { status: 404 })
    }

    return NextResponse.json({ user })
  } catch (error) {
    console.error("Profile fetch error:", error)
    return NextResponse.json({ message: "Failed to fetch profile" }, { status: 500 })
  }
}
