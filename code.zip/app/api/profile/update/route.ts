import { connectToDatabase } from "@/lib/mongodb"
import { type NextRequest, NextResponse } from "next/server"
import { ObjectId } from "mongodb"

export async function POST(req: NextRequest) {
  try {
    const token = req.headers.get("Authorization")?.split(" ")[1]

    if (!token) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const { bio, skills, interests, linkedinUrl, avatar } = await req.json()

    const { db } = await connectToDatabase()
    const usersCollection = db.collection("users")

    // In production, verify the token properly
    // For now, we'll extract the user ID from a cookie or header

    // Update user profile
    const result = await usersCollection.updateOne(
      { _id: new ObjectId() }, // This should be the actual user ID from token
      {
        $set: {
          bio,
          skills,
          interests,
          linkedinUrl,
          avatar,
          profileCompleted: true,
          updatedAt: new Date(),
        },
      },
    )

    return NextResponse.json({
      message: "Profile updated successfully",
      user: {
        bio,
        skills,
        interests,
      },
    })
  } catch (error) {
    console.error("Profile update error:", error)
    return NextResponse.json({ message: "Profile update failed" }, { status: 500 })
  }
}
