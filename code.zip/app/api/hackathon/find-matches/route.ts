import { connectToDatabase } from "@/lib/mongodb"
import { type NextRequest, NextResponse } from "next/server"

// Simple AI-like matching algorithm
function calculateCompatibility(userSkills: string[], requiredSkills: string[]): number {
  const matchedSkills = userSkills.filter((skill) =>
    requiredSkills.some((req) => req.toLowerCase().includes(skill.toLowerCase())),
  )
  return Math.round((matchedSkills.length / requiredSkills.length) * 100)
}

export async function POST(req: NextRequest) {
  try {
    const token = req.headers.get("Authorization")?.split(" ")[1]

    if (!token) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const { requiredSkills, teamSize, preferences } = await req.json()

    const { db } = await connectToDatabase()
    const usersCollection = db.collection("users")

    // Find users with matching skills
    const users = await usersCollection
      .find({
        skills: { $exists: true, $ne: "" },
      })
      .limit(50)
      .toArray()

    // Calculate compatibility score for each user
    const matches = users
      .map((user) => {
        const userSkills = user.skills?.split(",").map((s: string) => s.trim()) || []
        const compatibility = calculateCompatibility(userSkills, requiredSkills)

        return {
          _id: user._id,
          name: user.name,
          skills: userSkills,
          interests: user.interests?.split(",").map((i: string) => i.trim()) || [],
          college: user.college,
          department: user.department,
          bio: user.bio || "",
          compatibility,
        }
      })
      .filter((match) => match.compatibility > 0)
      .sort((a, b) => b.compatibility - a.compatibility)
      .slice(0, Number.parseInt(teamSize) + 5) // Show a few more than requested

    return NextResponse.json({ matches })
  } catch (error) {
    console.error("Find matches error:", error)
    return NextResponse.json({ message: "Failed to find matches" }, { status: 500 })
  }
}
