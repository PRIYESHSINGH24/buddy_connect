import { connectToDatabase } from "@/lib/mongodb"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(req: NextRequest) {
  try {
    const token = req.headers.get("Authorization")?.split(" ")[1]

    if (!token) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const { db } = await connectToDatabase()
    const teamsCollection = db.collection("hackathon_teams")

    // Fetch all teams with leader info
    const teams = await teamsCollection
      .aggregate([
        {
          $lookup: {
            from: "users",
            localField: "leaderId",
            foreignField: "_id",
            as: "leader",
          },
        },
        {
          $unwind: {
            path: "$leader",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $project: {
            teamName: 1,
            teamDescription: 1,
            members: 1,
            requiredSkills: 1,
            createdAt: 1,
            "leader.name": 1,
            "leader.college": 1,
          },
        },
        {
          $sort: { createdAt: -1 },
        },
      ])
      .toArray()

    // In production, filter for current user's teams
    const myTeams = teams.filter((t) => true) // Placeholder for actual user filter

    return NextResponse.json({
      teams,
      myTeams,
    })
  } catch (error) {
    console.error("Teams fetch error:", error)
    return NextResponse.json({ message: "Failed to fetch teams" }, { status: 500 })
  }
}
