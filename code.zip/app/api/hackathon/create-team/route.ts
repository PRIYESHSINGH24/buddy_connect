import { connectToDatabase } from "@/lib/mongodb"
import { type NextRequest, NextResponse } from "next/server"
import { ObjectId } from "mongodb"

export async function POST(req: NextRequest) {
  try {
    const token = req.headers.get("Authorization")?.split(" ")[1]

    if (!token) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const { teamName, teamDescription, requiredSkills, selectedMembers } = await req.json()

    if (!teamName || selectedMembers.length === 0) {
      return NextResponse.json({ message: "Team name and members are required" }, { status: 400 })
    }

    const { db } = await connectToDatabase()
    const teamsCollection = db.collection("hackathon_teams")
    const usersCollection = db.collection("users")

    // Get member details
    const members = await usersCollection
      .find({
        _id: { $in: selectedMembers.map((id) => new ObjectId(id)) },
      })
      .toArray()

    // In production, extract userId from token
    const team = {
      teamName,
      teamDescription,
      requiredSkills,
      leaderId: new ObjectId(),
      members: members.map((m) => ({
        _id: m._id,
        name: m.name,
        department: m.department,
        skills: m.skills?.split(",").map((s: string) => s.trim()) || [],
      })),
      createdAt: new Date(),
      status: "active",
    }

    const result = await teamsCollection.insertOne(team)

    return NextResponse.json(
      {
        message: "Team created successfully",
        team: {
          _id: result.insertedId,
          ...team,
        },
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Create team error:", error)
    return NextResponse.json({ message: "Failed to create team" }, { status: 500 })
  }
}
