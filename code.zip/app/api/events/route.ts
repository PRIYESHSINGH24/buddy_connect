import { connectToDatabase } from "@/lib/mongodb"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(req: NextRequest) {
  try {
    const token = req.headers.get("Authorization")?.split(" ")[1]

    if (!token) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const { db } = await connectToDatabase()
    const eventsCollection = db.collection("events")

    // Fetch events with organizer info
    const events = await eventsCollection
      .aggregate([
        {
          $lookup: {
            from: "users",
            localField: "organizerId",
            foreignField: "_id",
            as: "organizer",
          },
        },
        {
          $unwind: {
            path: "$organizer",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $project: {
            title: 1,
            description: 1,
            eventDate: 1,
            eventTime: 1,
            location: 1,
            category: 1,
            capacity: 1,
            registeredCount: 1,
            registrationLink: 1,
            createdAt: 1,
            "organizer.name": 1,
            "organizer.college": 1,
          },
        },
        {
          $sort: { eventDate: -1 },
        },
        {
          $limit: 100,
        },
      ])
      .toArray()

    return NextResponse.json({ events })
  } catch (error) {
    console.error("Events fetch error:", error)
    return NextResponse.json({ message: "Failed to fetch events" }, { status: 500 })
  }
}
