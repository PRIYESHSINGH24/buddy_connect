import { connectToDatabase } from "@/lib/mongodb"
import { type NextRequest, NextResponse } from "next/server"
import { ObjectId } from "mongodb"

export async function POST(req: NextRequest) {
  try {
    const token = req.headers.get("Authorization")?.split(" ")[1]

    if (!token) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const { title, description, eventDate, eventTime, location, category, capacity, registrationLink } =
      await req.json()

    if (!title || !description || !eventDate || !eventTime) {
      return NextResponse.json({ message: "Missing required fields" }, { status: 400 })
    }

    const { db } = await connectToDatabase()
    const eventsCollection = db.collection("events")

    const event = {
      title,
      description,
      eventDate,
      eventTime,
      location: location || "",
      category: category || "other",
      capacity: Number.parseInt(capacity) || 0,
      registrationLink: registrationLink || null,
      organizerId: new ObjectId(),
      createdAt: new Date(),
      registeredCount: 0,
      registeredUsers: [],
      status: "active",
    }

    const result = await eventsCollection.insertOne(event)

    return NextResponse.json(
      {
        message: "Event created successfully",
        event: {
          _id: result.insertedId,
          ...event,
        },
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Event creation error:", error)
    return NextResponse.json({ message: "Failed to create event" }, { status: 500 })
  }
}
