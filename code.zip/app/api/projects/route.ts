import { connectToDatabase } from "@/lib/mongodb"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(req: NextRequest) {
  try {
    const token = req.headers.get("Authorization")?.split(" ")[1]

    if (!token) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const { db } = await connectToDatabase()
    const projectsCollection = db.collection("projects")

    // Fetch projects with author info
    const projects = await projectsCollection
      .aggregate([
        {
          $lookup: {
            from: "users",
            localField: "authorId",
            foreignField: "_id",
            as: "author",
          },
        },
        {
          $unwind: {
            path: "$author",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $project: {
            title: 1,
            description: 1,
            githubUrl: 1,
            liveUrl: 1,
            technologies: 1,
            teamSize: 1,
            createdAt: 1,
            likes: 1,
            "author.name": 1,
            "author.college": 1,
            "author.department": 1,
          },
        },
        {
          $sort: { createdAt: -1 },
        },
        {
          $limit: 100,
        },
      ])
      .toArray()

    return NextResponse.json({ projects })
  } catch (error) {
    console.error("Projects fetch error:", error)
    return NextResponse.json({ message: "Failed to fetch projects" }, { status: 500 })
  }
}
