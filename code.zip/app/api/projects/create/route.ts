import { connectToDatabase } from "@/lib/mongodb"
import { type NextRequest, NextResponse } from "next/server"
import { ObjectId } from "mongodb"

export async function POST(req: NextRequest) {
  try {
    const token = req.headers.get("Authorization")?.split(" ")[1]

    if (!token) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const { title, description, githubUrl, liveUrl, technologies, teamSize } = await req.json()

    if (!title || !description || !githubUrl) {
      return NextResponse.json({ message: "Missing required fields" }, { status: 400 })
    }

    const { db } = await connectToDatabase()
    const projectsCollection = db.collection("projects")

    const project = {
      title,
      description,
      githubUrl,
      liveUrl: liveUrl || null,
      technologies: technologies || "",
      teamSize: teamSize || "",
      authorId: new ObjectId(),
      createdAt: new Date(),
      likes: 0,
      likedBy: [],
      views: 0,
    }

    const result = await projectsCollection.insertOne(project)

    return NextResponse.json(
      {
        message: "Project created successfully",
        project: {
          _id: result.insertedId,
          ...project,
        },
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Project creation error:", error)
    return NextResponse.json({ message: "Failed to create project" }, { status: 500 })
  }
}
