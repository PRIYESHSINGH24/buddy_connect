import { connectToDatabase } from "@/lib/mongodb"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(req: NextRequest) {
  try {
    const token = req.headers.get("Authorization")?.split(" ")[1]

    if (!token) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const { db } = await connectToDatabase()
    const postsCollection = db.collection("posts")
    const usersCollection = db.collection("users")

    // Fetch posts with author info
    const posts = await postsCollection
      .aggregate([
        {
          $lookup: {
            from: "users",
            localField: "authorId",
            foreignField: "_id",
            as: "author",
          },
        },
        {
          $unwind: "$author",
        },
        {
          $project: {
            content: 1,
            createdAt: 1,
            likes: 1,
            comments: 1,
            shares: 1,
            "author.name": 1,
            "author.college": 1,
            "author.department": 1,
          },
        },
        {
          $sort: { createdAt: -1 },
        },
        {
          $limit: 50,
        },
      ])
      .toArray()

    return NextResponse.json({ posts })
  } catch (error) {
    console.error("Posts fetch error:", error)
    return NextResponse.json({ message: "Failed to fetch posts" }, { status: 500 })
  }
}
