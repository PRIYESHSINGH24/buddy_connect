import { connectToDatabase } from "@/lib/mongodb"
import { type NextRequest, NextResponse } from "next/server"
import { ObjectId } from "mongodb"

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const token = req.headers.get("Authorization")?.split(" ")[1]

    if (!token) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const { db } = await connectToDatabase()
    const postsCollection = db.collection("posts")

    // In production, extract userId from token
    const userId = new ObjectId()

    const result = await postsCollection.findOneAndUpdate(
      { _id: new ObjectId(params.id) },
      {
        $addToSet: { likedBy: userId },
        $inc: { likes: 1 },
      },
      { returnDocument: "after" },
    )

    if (!result.value) {
      return NextResponse.json({ message: "Post not found" }, { status: 404 })
    }

    return NextResponse.json({ post: result.value })
  } catch (error) {
    console.error("Like error:", error)
    return NextResponse.json({ message: "Failed to like post" }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const token = req.headers.get("Authorization")?.split(" ")[1]

    if (!token) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const { db } = await connectToDatabase()
    const postsCollection = db.collection("posts")

    // In production, extract userId from token
    const userId = new ObjectId()

    const result = await postsCollection.findOneAndUpdate(
      { _id: new ObjectId(params.id) },
      {
        $pull: { likedBy: userId },
        $inc: { likes: -1 },
      },
      { returnDocument: "after" },
    )

    if (!result.value) {
      return NextResponse.json({ message: "Post not found" }, { status: 404 })
    }

    return NextResponse.json({ post: result.value })
  } catch (error) {
    console.error("Unlike error:", error)
    return NextResponse.json({ message: "Failed to unlike post" }, { status: 500 })
  }
}
