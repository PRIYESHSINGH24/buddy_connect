import { connectToDatabase } from "@/lib/mongodb"
import { type NextRequest, NextResponse } from "next/server"
import { ObjectId } from "mongodb"

export async function POST(req: NextRequest) {
  try {
    const token = req.headers.get("Authorization")?.split(" ")[1]

    if (!token) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const { content } = await req.json()

    if (!content || content.trim().length === 0) {
      return NextResponse.json({ message: "Post content cannot be empty" }, { status: 400 })
    }

    const { db } = await connectToDatabase()
    const postsCollection = db.collection("posts")

    // In production, extract userId from token
    const post = {
      authorId: new ObjectId(),
      content: content.trim(),
      createdAt: new Date(),
      likes: 0,
      likedBy: [],
      comments: 0,
      shares: 0,
    }

    const result = await postsCollection.insertOne(post)

    return NextResponse.json(
      {
        message: "Post created successfully",
        post: {
          _id: result.insertedId,
          ...post,
        },
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Post creation error:", error)
    return NextResponse.json({ message: "Failed to create post" }, { status: 500 })
  }
}
