import { connectToDatabase } from "@/lib/mongodb"
import { hashPassword, generateToken } from "@/lib/auth"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(req: NextRequest) {
  try {
    const { name, email, password, college, department, year } = await req.json()

    const { db } = await connectToDatabase()
    const usersCollection = db.collection("users")

    // Check if user exists
    const existingUser = await usersCollection.findOne({ email })
    if (existingUser) {
      return NextResponse.json({ message: "User already exists" }, { status: 400 })
    }

    // Create user
    const hashedPassword = hashPassword(password)
    const user = {
      name,
      email,
      password: hashedPassword,
      college,
      department,
      year: Number.parseInt(year),
      createdAt: new Date(),
      bio: "",
      avatar: "",
      linkedinUrl: "",
      skills: [],
      experience: [],
    }

    const result = await usersCollection.insertOne(user)

    const token = generateToken(result.insertedId.toString())

    return NextResponse.json(
      {
        token,
        user: {
          id: result.insertedId,
          name,
          email,
          college,
          department,
          year,
        },
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Signup error:", error)
    return NextResponse.json({ message: "Signup failed" }, { status: 500 })
  }
}
