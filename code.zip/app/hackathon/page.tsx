"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { TeamMatcher } from "@/components/hackathon/team-matcher"
import { TeamCard } from "@/components/hackathon/team-card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function HackathonPage() {
  const router = useRouter()
  const [teams, setTeams] = useState<any[]>([])
  const [myTeams, setMyTeams] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<"find" | "browse" | "myteams">("find")

  useEffect(() => {
    fetchTeams()
  }, [])

  const fetchTeams = async () => {
    try {
      const token = localStorage.getItem("token")
      if (!token) {
        router.push("/login")
        return
      }

      const res = await fetch("/api/hackathon/teams", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (!res.ok) {
        if (res.status === 401) {
          router.push("/login")
          return
        }
        throw new Error("Failed to fetch teams")
      }

      const data = await res.json()
      setTeams(data.teams || [])
      setMyTeams(data.myTeams || [])
    } catch (err) {
      console.error("Error fetching teams:", err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800">
      <nav className="sticky top-0 z-50 bg-slate-900/95 backdrop-blur border-b border-slate-700">
        <div className="max-w-4xl mx-auto flex justify-between items-center px-6 py-4">
          <Link href="/feed" className="text-2xl font-bold text-blue-400">
            CollegeLink
          </Link>
          <Link href="/feed">
            <Button variant="ghost" className="text-slate-300 hover:text-white">
              Back to Feed
            </Button>
          </Link>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Hackathon Teams</h1>
          <p className="text-slate-400">Find teammates, create teams, and collaborate on hackathon ideas</p>
        </div>

        <div className="flex gap-2 mb-8 border-b border-slate-700">
          {(["find", "browse", "myteams"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-3 font-medium border-b-2 transition ${
                activeTab === tab
                  ? "text-blue-400 border-blue-400"
                  : "text-slate-400 border-transparent hover:text-slate-300"
              }`}
            >
              {tab === "find" && "Find Team Members"}
              {tab === "browse" && "Browse Teams"}
              {tab === "myteams" && `My Teams (${myTeams.length})`}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="text-center text-slate-400">Loading...</div>
        ) : (
          <>
            {activeTab === "find" && <TeamMatcher onTeamCreated={fetchTeams} />}

            {activeTab === "browse" && (
              <div>
                {teams.length === 0 ? (
                  <div className="text-center text-slate-400">No teams available. Create the first one!</div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {teams.map((team) => (
                      <TeamCard key={team._id} team={team} />
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === "myteams" && (
              <div>
                {myTeams.length === 0 ? (
                  <div className="text-center text-slate-400">
                    You haven't created any teams yet. Use the team matcher to find members!
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {myTeams.map((team) => (
                      <TeamCard key={team._id} team={team} />
                    ))}
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}
