"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { ProjectForm } from "@/components/projects/project-form"
import { ProjectCard } from "@/components/projects/project-card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function ProjectsPage() {
  const router = useRouter()
  const [projects, setProjects] = useState<any[]>([])
  const [showForm, setShowForm] = useState(false)
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")

  useEffect(() => {
    fetchProjects()
  }, [])

  const fetchProjects = async () => {
    try {
      const token = localStorage.getItem("token")
      if (!token) {
        router.push("/login")
        return
      }

      const res = await fetch("/api/projects", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (!res.ok) {
        if (res.status === 401) {
          router.push("/login")
          return
        }
        throw new Error("Failed to fetch projects")
      }

      const data = await res.json()
      setProjects(data.projects || [])
    } catch (err) {
      console.error("Error fetching projects:", err)
    } finally {
      setLoading(false)
    }
  }

  const filteredProjects = projects.filter(
    (project) =>
      project.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      project.description.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800">
      <nav className="sticky top-0 z-50 bg-slate-900/95 backdrop-blur border-b border-slate-700">
        <div className="max-w-4xl mx-auto flex justify-between items-center px-6 py-4">
          <Link href="/feed" className="text-2xl font-bold text-blue-400">
            CollegeLink
          </Link>
          <Link href="/feed">
            <Button variant="ghost" className="text-slate-300 hover:text-white">
              Back to Feed
            </Button>
          </Link>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto p-6">
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">Projects</h1>
              <p className="text-slate-400">Discover projects built by students in your college</p>
            </div>
            <Button onClick={() => setShowForm(!showForm)} className="bg-blue-600 hover:bg-blue-700 text-white">
              {showForm ? "Cancel" : "+ Share Project"}
            </Button>
          </div>

          {showForm && (
            <div className="mb-8">
              <ProjectForm
                onSubmit={() => {
                  setShowForm(false)
                  fetchProjects()
                }}
                onCancel={() => setShowForm(false)}
              />
            </div>
          )}

          <input
            type="text"
            placeholder="Search projects by title or technology..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded text-white placeholder-slate-400 focus:border-blue-500 focus:outline-none"
          />
        </div>

        {loading ? (
          <div className="text-center text-slate-400">Loading projects...</div>
        ) : filteredProjects.length === 0 ? (
          <div className="text-center text-slate-400">
            {searchTerm ? "No projects match your search." : "No projects yet. Be the first to share!"}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredProjects.map((project) => (
              <ProjectCard key={project._id} project={project} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
