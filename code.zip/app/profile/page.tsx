"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { ProfileCard } from "@/components/profile/profile-card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function ProfilePage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const token = localStorage.getItem("token")
        const userData = localStorage.getItem("user")

        if (!token || !userData) {
          router.push("/login")
          return
        }

        const res = await fetch("/api/profile/me", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        })

        if (!res.ok) {
          router.push("/login")
          return
        }

        const data = await res.json()
        setUser(data.user)
      } catch (error) {
        console.error("Error fetching profile:", error)
        router.push("/login")
      } finally {
        setLoading(false)
      }
    }

    fetchProfile()
  }, [router])

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center">
        <p className="text-white">Loading...</p>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center">
        <p className="text-white">No user found</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800">
      <nav className="flex justify-between items-center px-8 py-4 border-b border-slate-700">
        <div className="text-2xl font-bold text-blue-400">CollegeLink</div>
        <div className="flex gap-4">
          <Link href="/feed">
            <Button variant="ghost" className="text-slate-300 hover:text-white">
              Feed
            </Button>
          </Link>
          <Button variant="ghost" className="text-slate-300 hover:text-white">
            Logout
          </Button>
        </div>
      </nav>

      <div className="max-w-2xl mx-auto p-8">
        <ProfileCard user={user} isOwner={true} />
      </div>
    </div>
  )
}
