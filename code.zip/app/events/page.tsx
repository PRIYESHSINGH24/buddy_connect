"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { EventForm } from "@/components/events/event-form"
import { EventCard } from "@/components/events/event-card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function EventsPage() {
  const router = useRouter()
  const [events, setEvents] = useState<any[]>([])
  const [showForm, setShowForm] = useState(false)
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState<"all" | "upcoming" | "ended">("upcoming")

  useEffect(() => {
    fetchEvents()
  }, [])

  const fetchEvents = async () => {
    try {
      const token = localStorage.getItem("token")
      if (!token) {
        router.push("/login")
        return
      }

      const res = await fetch("/api/events", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (!res.ok) {
        if (res.status === 401) {
          router.push("/login")
          return
        }
        throw new Error("Failed to fetch events")
      }

      const data = await res.json()
      setEvents(data.events || [])
    } catch (err) {
      console.error("Error fetching events:", err)
    } finally {
      setLoading(false)
    }
  }

  const filteredEvents = events.filter((event) => {
    const eventDateTime = new Date(`${event.eventDate}T${event.eventTime}`)
    const isUpcoming = eventDateTime > new Date()

    if (filter === "upcoming") return isUpcoming
    if (filter === "ended") return !isUpcoming
    return true
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800">
      <nav className="sticky top-0 z-50 bg-slate-900/95 backdrop-blur border-b border-slate-700">
        <div className="max-w-4xl mx-auto flex justify-between items-center px-6 py-4">
          <Link href="/feed" className="text-2xl font-bold text-blue-400">
            CollegeLink
          </Link>
          <Link href="/feed">
            <Button variant="ghost" className="text-slate-300 hover:text-white">
              Back to Feed
            </Button>
          </Link>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto p-6">
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">College Events</h1>
              <p className="text-slate-400">Discover and create events happening in your college</p>
            </div>
            <Button onClick={() => setShowForm(!showForm)} className="bg-blue-600 hover:bg-blue-700 text-white">
              {showForm ? "Cancel" : "+ Create Event"}
            </Button>
          </div>

          {showForm && (
            <div className="mb-8">
              <EventForm
                onSubmit={() => {
                  setShowForm(false)
                  fetchEvents()
                }}
                onCancel={() => setShowForm(false)}
              />
            </div>
          )}

          <div className="flex gap-2 mb-6">
            {(["all", "upcoming", "ended"] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-4 py-2 rounded capitalize transition ${
                  filter === f ? "bg-blue-600 text-white" : "bg-slate-700 text-slate-300 hover:bg-slate-600"
                }`}
              >
                {f === "all" ? "All Events" : f === "upcoming" ? "Upcoming" : "Past Events"}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="text-center text-slate-400">Loading events...</div>
        ) : filteredEvents.length === 0 ? (
          <div className="text-center text-slate-400">
            {filter === "upcoming" ? "No upcoming events. Check back soon!" : "No past events"}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredEvents.map((event) => (
              <EventCard key={event._id} event={event} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
