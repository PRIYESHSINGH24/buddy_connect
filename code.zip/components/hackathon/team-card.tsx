"use client"

import { Card } from "@/components/ui/card"

interface TeamMember {
  name: string
  skills: string[]
  department: string
}

interface TeamCardProps {
  team: {
    _id: string
    teamName: string
    teamDescription: string
    members: TeamMember[]
    requiredSkills: string[]
    createdAt: string
    leader: {
      name: string
      college: string
    }
  }
}

export function TeamCard({ team }: TeamCardProps) {
  return (
    <Card className="bg-slate-800 border-slate-700 p-6 hover:border-blue-600 transition">
      <div className="mb-4">
        <h3 className="text-xl font-bold text-white mb-1">{team.teamName}</h3>
        <p className="text-slate-400 text-sm">
          Led by <span className="text-blue-400">{team.leader.name}</span>
        </p>
      </div>

      <p className="text-slate-300 mb-4 text-sm">{team.teamDescription}</p>

      <div className="mb-4">
        <p className="text-slate-400 text-xs font-semibold mb-2">TEAM MEMBERS ({team.members.length})</p>
        <div className="space-y-2">
          {team.members.map((member, idx) => (
            <div key={idx} className="flex items-start justify-between">
              <div>
                <p className="text-white text-sm font-medium">{member.name}</p>
                <p className="text-slate-400 text-xs">{member.department}</p>
              </div>
              <div className="flex flex-wrap gap-1 justify-end">
                {member.skills.slice(0, 2).map((skill) => (
                  <span key={skill} className="px-2 py-0.5 bg-blue-600/20 text-blue-400 text-xs rounded">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div>
        <p className="text-slate-400 text-xs font-semibold mb-2">LOOKING FOR</p>
        <div className="flex flex-wrap gap-2">
          {team.requiredSkills.map((skill) => (
            <span key={skill} className="px-3 py-1 bg-slate-700 text-slate-300 text-xs rounded-full">
              {skill}
            </span>
          ))}
        </div>
      </div>
    </Card>
  )
}
