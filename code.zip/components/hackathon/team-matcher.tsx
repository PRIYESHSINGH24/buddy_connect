"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface MatchedUser {
  _id: string
  name: string
  skills: string[]
  interests: string[]
  college: string
  department: string
  bio: string
  compatibility: number
}

interface TeamMatcherProps {
  onTeamCreated?: () => void
}

export function TeamMatcher({ onTeamCreated }: TeamMatcherProps) {
  const [teamName, setTeamName] = useState("")
  const [teamDescription, setTeamDescription] = useState("")
  const [requiredSkills, setRequiredSkills] = useState("")
  const [teamSize, setTeamSize] = useState("3")
  const [matches, setMatches] = useState<MatchedUser[]>([])
  const [selectedMembers, setSelectedMembers] = useState<string[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [step, setStep] = useState<"form" | "matches">("form")

  const handleFindMatches = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (!teamName.trim() || !requiredSkills.trim()) {
      setError("Team name and required skills are mandatory")
      return
    }

    setLoading(true)

    try {
      const token = localStorage.getItem("token")
      const res = await fetch("/api/hackathon/find-matches", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          requiredSkills: requiredSkills.split(",").map((s) => s.trim()),
          teamSize: Number.parseInt(teamSize),
          preferences: teamDescription,
        }),
      })

      const data = await res.json()

      if (!res.ok) {
        setError(data.message || "Failed to find matches")
        return
      }

      setMatches(data.matches || [])
      setStep("matches")
    } catch (err) {
      setError("An error occurred. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  const toggleMember = (userId: string) => {
    setSelectedMembers((prev) => (prev.includes(userId) ? prev.filter((id) => id !== userId) : [...prev, userId]))
  }

  const handleCreateTeam = async () => {
    if (selectedMembers.length === 0) {
      setError("Select at least one team member")
      return
    }

    setLoading(true)
    setError("")

    try {
      const token = localStorage.getItem("token")
      const res = await fetch("/api/hackathon/create-team", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          teamName,
          teamDescription,
          requiredSkills: requiredSkills.split(",").map((s) => s.trim()),
          selectedMembers,
        }),
      })

      const data = await res.json()

      if (!res.ok) {
        setError(data.message || "Failed to create team")
        return
      }

      setTeamName("")
      setTeamDescription("")
      setRequiredSkills("")
      setSelectedMembers([])
      setMatches([])
      setStep("form")
      onTeamCreated?.()
    } catch (err) {
      setError("An error occurred. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  if (step === "matches") {
    return (
      <div className="space-y-6">
        <Card className="bg-slate-800 border-slate-700 p-6">
          <h2 className="text-2xl font-bold text-white mb-4">AI-Matched Team Members</h2>
          <p className="text-slate-400 mb-6">Select the members you want to invite to your {teamName} team</p>

          {error && <div className="p-3 bg-red-900/20 border border-red-700 text-red-400 rounded mb-6">{error}</div>}

          <div className="space-y-3 mb-6">
            {matches.length === 0 ? (
              <p className="text-slate-400">No matching members found</p>
            ) : (
              matches.map((match) => (
                <div
                  key={match._id}
                  className="p-4 bg-slate-700 rounded-lg border border-slate-600 hover:border-blue-600 transition cursor-pointer"
                  onClick={() => toggleMember(match._id)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <input
                          type="checkbox"
                          checked={selectedMembers.includes(match._id)}
                          onChange={() => toggleMember(match._id)}
                          onClick={(e) => e.stopPropagation()}
                          className="w-4 h-4 rounded border-slate-500 cursor-pointer"
                        />
                        <h3 className="text-white font-semibold">{match.name}</h3>
                        <span className="px-2 py-1 bg-blue-600/20 text-blue-400 text-xs rounded">
                          {match.compatibility}% match
                        </span>
                      </div>
                      <p className="text-slate-400 text-sm mb-2">
                        {match.department} • {match.college}
                      </p>
                      <p className="text-slate-300 text-sm mb-3">{match.bio}</p>
                      <div className="flex gap-2 mb-2">
                        {match.skills.slice(0, 3).map((skill) => (
                          <span key={skill} className="px-2 py-1 bg-slate-600 text-slate-300 text-xs rounded">
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="flex gap-3">
            <Button
              onClick={() => {
                setStep("form")
                setSelectedMembers([])
              }}
              variant="outline"
              className="flex-1 border-slate-600 text-slate-300"
            >
              Go Back
            </Button>
            <Button
              onClick={handleCreateTeam}
              disabled={loading || selectedMembers.length === 0}
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
            >
              {loading ? "Creating Team..." : `Create Team (${selectedMembers.length} members)`}
            </Button>
          </div>
        </Card>
      </div>
    )
  }

  return (
    <Card className="bg-slate-800 border-slate-700 p-6">
      <h2 className="text-2xl font-bold text-white mb-6">Hackathon Team Matcher</h2>
      <p className="text-slate-400 mb-6">Use AI to find the perfect team members for your hackathon</p>

      {error && <div className="p-3 bg-red-900/20 border border-red-700 text-red-400 rounded mb-6">{error}</div>}

      <form onSubmit={handleFindMatches} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">Team Name *</label>
          <input
            type="text"
            value={teamName}
            onChange={(e) => setTeamName(e.target.value)}
            placeholder="e.g., AI Innovators, Web Warriors"
            className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded text-white placeholder-slate-400 focus:border-blue-500 focus:outline-none"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">Required Skills (comma-separated) *</label>
          <input
            type="text"
            value={requiredSkills}
            onChange={(e) => setRequiredSkills(e.target.value)}
            placeholder="React, Node.js, Machine Learning, UI/UX Design..."
            className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded text-white placeholder-slate-400 focus:border-blue-500 focus:outline-none"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">Team Description</label>
          <textarea
            value={teamDescription}
            onChange={(e) => setTeamDescription(e.target.value)}
            placeholder="What's your hackathon idea? What are you looking to build?"
            rows={4}
            className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded text-white placeholder-slate-400 focus:border-blue-500 focus:outline-none resize-none"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">Team Size</label>
          <select
            value={teamSize}
            onChange={(e) => setTeamSize(e.target.value)}
            className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded text-white focus:border-blue-500 focus:outline-none"
          >
            <option value="2">2 Members</option>
            <option value="3">3 Members</option>
            <option value="4">4 Members</option>
            <option value="5">5 Members</option>
            <option value="6">6+ Members</option>
          </select>
        </div>

        <Button type="submit" disabled={loading} className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3">
          {loading ? "Finding Matches..." : "Find Team Members"}
        </Button>
      </form>
    </Card>
  )
}
