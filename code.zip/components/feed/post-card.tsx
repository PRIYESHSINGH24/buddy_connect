"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"

interface PostCardProps {
  post: {
    _id: string
    author: {
      name: string
      college: string
      department: string
    }
    content: string
    createdAt: string
    likes: number
    comments: number
    shares: number
    liked?: boolean
  }
  onLike?: (postId: string) => void
}

export function PostCard({ post, onLike }: PostCardProps) {
  const [liked, setLiked] = useState(post.liked || false)
  const [likeCount, setLikeCount] = useState(post.likes || 0)

  const handleLike = async () => {
    try {
      const token = localStorage.getItem("token")
      const method = liked ? "DELETE" : "POST"

      const res = await fetch(`/api/posts/${post._id}/like`, {
        method,
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (res.ok) {
        setLiked(!liked)
        setLikeCount(liked ? likeCount - 1 : likeCount + 1)
        onLike?.(post._id)
      }
    } catch (err) {
      console.error("Error liking post:", err)
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffMins = Math.floor(diffMs / 60000)

    if (diffMins < 1) return "just now"
    if (diffMins < 60) return `${diffMins}m ago`
    if (diffMins < 1440) return `${Math.floor(diffMins / 60)}h ago`
    return `${Math.floor(diffMins / 1440)}d ago`
  }

  return (
    <Card className="bg-slate-800 border-slate-700 p-6 mb-4">
      <div className="flex gap-4">
        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white font-bold">
          {post.author.name.charAt(0).toUpperCase()}
        </div>

        <div className="flex-1">
          <div className="flex justify-between items-start mb-2">
            <div>
              <h3 className="text-white font-semibold">{post.author.name}</h3>
              <p className="text-slate-400 text-sm">
                {post.author.department} • {post.author.college}
              </p>
            </div>
            <p className="text-slate-500 text-xs">{formatDate(post.createdAt)}</p>
          </div>

          <p className="text-slate-200 mb-4 leading-relaxed">{post.content}</p>

          <div className="flex justify-between text-slate-400 text-sm border-t border-slate-700 pt-3">
            <button
              onClick={handleLike}
              className={`flex-1 py-2 rounded hover:bg-slate-700/50 transition flex items-center justify-center gap-2 ${
                liked ? "text-blue-400" : "hover:text-slate-300"
              }`}
            >
              <span>👍</span>
              <span>{likeCount}</span>
            </button>
            <button className="flex-1 py-2 rounded hover:bg-slate-700/50 transition flex items-center justify-center gap-2 hover:text-slate-300">
              <span>💬</span>
              <span>{post.comments}</span>
            </button>
            <button className="flex-1 py-2 rounded hover:bg-slate-700/50 transition flex items-center justify-center gap-2 hover:text-slate-300">
              <span>🔗</span>
              <span>{post.shares}</span>
            </button>
          </div>
        </div>
      </div>
    </Card>
  )
}
