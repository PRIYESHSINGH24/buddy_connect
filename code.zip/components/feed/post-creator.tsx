"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface PostCreatorProps {
  onPostCreated?: () => void
}

export function PostCreator({ onPostCreated }: PostCreatorProps) {
  const [content, setContent] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!content.trim()) return

    setLoading(true)
    setError("")

    try {
      const token = localStorage.getItem("token")
      const res = await fetch("/api/posts/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ content }),
      })

      if (!res.ok) {
        const data = await res.json()
        setError(data.message || "Failed to create post")
        return
      }

      setContent("")
      onPostCreated?.()
    } catch (err) {
      setError("An error occurred. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="bg-slate-800 border-slate-700 p-6 mb-6">
      <div className="flex gap-4 mb-4">
        <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-sm">
          U
        </div>
        <form onSubmit={handleSubmit} className="flex-1 space-y-3">
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="What's on your mind? Share an update, ask a question, or post an opportunity..."
            rows={3}
            className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded text-white placeholder-slate-400 focus:border-blue-500 focus:outline-none resize-none"
          />

          {error && <div className="p-2 bg-red-900/20 border border-red-700 text-red-400 rounded text-sm">{error}</div>}

          <div className="flex justify-end gap-2">
            <Button
              type="button"
              onClick={() => setContent("")}
              variant="outline"
              className="border-slate-600 text-slate-300"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={loading || !content.trim()}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              {loading ? "Posting..." : "Post"}
            </Button>
          </div>
        </form>
      </div>
    </Card>
  )
}
