"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

export function ProfileSetupForm() {
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    bio: "",
    skills: "",
    linkedinUrl: "",
    avatar: "",
    interests: "",
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleLinkedInImport = async () => {
    setError("")
    setLoading(true)

    try {
      // In production, you would integrate with a real LinkedIn API
      // For now, we'll use a placeholder that shows how to fetch LinkedIn data
      const linkedinUrl = formData.linkedinUrl
      if (!linkedinUrl.includes("linkedin.com")) {
        setError("Please enter a valid LinkedIn URL")
        return
      }

      // Mock API call to extract LinkedIn data
      const res = await fetch("/api/profile/linkedin-import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ linkedinUrl }),
      })

      if (!res.ok) {
        setError("Failed to import LinkedIn profile. You can fill in details manually.")
        return
      }

      const data = await res.json()
      setFormData((prev) => ({
        ...prev,
        bio: data.bio || prev.bio,
        skills: data.skills?.join(", ") || prev.skills,
      }))

      setStep(2)
    } catch (err) {
      console.error("LinkedIn import error:", err)
      setError("Could not import LinkedIn data. Please continue manually.")
      setStep(2)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    try {
      const token = localStorage.getItem("token")
      const res = await fetch("/api/profile/update", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(formData),
      })

      const data = await res.json()

      if (!res.ok) {
        setError(data.message || "Failed to update profile")
        return
      }

      router.push("/feed")
    } catch (err) {
      setError("An error occurred. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-2xl bg-slate-800 border-slate-700">
      <div className="p-8">
        <h1 className="text-3xl font-bold text-white mb-2">Complete Your Profile</h1>
        <p className="text-slate-400 mb-8">Help other students get to know you better</p>

        <div className="flex gap-2 mb-8">
          <div className={`flex-1 h-1 rounded ${step >= 1 ? "bg-blue-600" : "bg-slate-700"}`}></div>
          <div className={`flex-1 h-1 rounded ${step >= 2 ? "bg-blue-600" : "bg-slate-700"}`}></div>
        </div>

        {error && <div className="p-3 bg-red-900/20 border border-red-700 text-red-400 rounded mb-6">{error}</div>}

        <form onSubmit={handleSubmit} className="space-y-6">
          {step === 1 ? (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">LinkedIn Profile URL (Optional)</label>
                <div className="flex gap-2">
                  <input
                    type="url"
                    name="linkedinUrl"
                    value={formData.linkedinUrl}
                    onChange={handleChange}
                    placeholder="https://linkedin.com/in/yourprofile"
                    className="flex-1 px-4 py-2 bg-slate-700 border border-slate-600 rounded text-white placeholder-slate-400 focus:border-blue-500 focus:outline-none"
                  />
                  <Button
                    type="button"
                    onClick={handleLinkedInImport}
                    disabled={loading || !formData.linkedinUrl}
                    variant="outline"
                    className="border-blue-600 text-blue-400 hover:bg-blue-600/10 bg-transparent"
                  >
                    {loading ? "Importing..." : "Import"}
                  </Button>
                </div>
                <p className="text-xs text-slate-400 mt-2">
                  We'll use your LinkedIn profile to populate your details automatically
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Or continue without LinkedIn</label>
                <Button
                  type="button"
                  onClick={() => setStep(2)}
                  variant="outline"
                  className="w-full border-slate-600 text-slate-300"
                >
                  Continue Manually
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Bio</label>
                <textarea
                  name="bio"
                  value={formData.bio}
                  onChange={handleChange}
                  placeholder="Tell us about yourself, your interests, and what you're looking for..."
                  rows={4}
                  className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded text-white placeholder-slate-400 focus:border-blue-500 focus:outline-none resize-none"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Skills (comma-separated)</label>
                <input
                  type="text"
                  name="skills"
                  value={formData.skills}
                  onChange={handleChange}
                  placeholder="React, TypeScript, Python, Machine Learning..."
                  className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded text-white placeholder-slate-400 focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Interests (comma-separated)</label>
                <input
                  type="text"
                  name="interests"
                  value={formData.interests}
                  onChange={handleChange}
                  placeholder="Web Development, AI, Startups, Design..."
                  className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded text-white placeholder-slate-400 focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div className="flex gap-4">
                <Button
                  type="button"
                  onClick={() => setStep(1)}
                  variant="outline"
                  className="flex-1 border-slate-600 text-slate-300"
                >
                  Back
                </Button>
                <Button type="submit" disabled={loading} className="flex-1 bg-blue-600 hover:bg-blue-700 text-white">
                  {loading ? "Saving..." : "Complete Profile"}
                </Button>
              </div>
            </div>
          )}
        </form>
      </div>
    </Card>
  )
}
