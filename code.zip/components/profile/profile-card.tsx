"use client"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

interface ProfileCardProps {
  user: {
    _id: string
    name: string
    email: string
    college: string
    department: string
    year: number
    bio?: string
    skills?: string
    interests?: string
    avatar?: string
  }
  isOwner?: boolean
  onEdit?: () => void
}

export function ProfileCard({ user, isOwner = false, onEdit }: ProfileCardProps) {
  return (
    <Card className="bg-slate-800 border-slate-700 overflow-hidden">
      <div className="h-24 bg-gradient-to-r from-blue-600 to-blue-500"></div>

      <div className="px-6 pb-6">
        <div className="flex justify-between items-start -mt-12 mb-4">
          <div className="w-20 h-20 rounded-full bg-slate-700 border-4 border-slate-800 flex items-center justify-center text-3xl font-bold text-blue-400">
            {user.name.charAt(0).toUpperCase()}
          </div>
          {isOwner && (
            <Button
              onClick={onEdit}
              variant="outline"
              className="border-blue-600 text-blue-400 hover:bg-blue-600/10 bg-transparent"
            >
              Edit Profile
            </Button>
          )}
        </div>

        <h2 className="text-2xl font-bold text-white">{user.name}</h2>
        <p className="text-blue-400 font-medium mb-2">
          {user.department} • Year {user.year}
        </p>
        <p className="text-slate-400 text-sm mb-4">{user.college}</p>

        {user.bio && (
          <>
            <h3 className="text-sm font-semibold text-slate-300 mt-4 mb-2">About</h3>
            <p className="text-slate-400 text-sm">{user.bio}</p>
          </>
        )}

        {user.skills && (
          <>
            <h3 className="text-sm font-semibold text-slate-300 mt-4 mb-2">Skills</h3>
            <div className="flex flex-wrap gap-2">
              {user.skills.split(",").map((skill) => (
                <span
                  key={skill}
                  className="px-3 py-1 bg-blue-600/20 border border-blue-600 text-blue-400 text-xs rounded-full"
                >
                  {skill.trim()}
                </span>
              ))}
            </div>
          </>
        )}

        {user.interests && (
          <>
            <h3 className="text-sm font-semibold text-slate-300 mt-4 mb-2">Interests</h3>
            <div className="flex flex-wrap gap-2">
              {user.interests.split(",").map((interest) => (
                <span key={interest} className="px-3 py-1 bg-slate-700 text-slate-300 text-xs rounded-full">
                  {interest.trim()}
                </span>
              ))}
            </div>
          </>
        )}
      </div>
    </Card>
  )
}
