"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

interface EventCardProps {
  event: {
    _id: string
    title: string
    description: string
    eventDate: string
    eventTime: string
    location: string
    category: string
    capacity: number
    registeredCount: number
    registrationLink?: string
    organizer: {
      name: string
      college: string
    }
  }
}

export function EventCard({ event }: EventCardProps) {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    })
  }

  const isUpcoming = new Date(`${event.eventDate}T${event.eventTime}`) > new Date()

  return (
    <Card className="bg-slate-800 border-slate-700 overflow-hidden hover:border-blue-600 transition">
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <span
                className={`px-2 py-1 text-xs rounded-full font-medium ${
                  isUpcoming ? "bg-green-600/20 text-green-400" : "bg-slate-700 text-slate-400"
                }`}
              >
                {isUpcoming ? "📅 Upcoming" : "✓ Ended"}
              </span>
              <span className="px-2 py-1 bg-blue-600/20 text-blue-400 text-xs rounded-full capitalize">
                {event.category}
              </span>
            </div>
            <h3 className="text-xl font-bold text-white mb-1">{event.title}</h3>
            <p className="text-slate-400 text-sm">
              by <span className="text-blue-400">{event.organizer.name}</span>
            </p>
          </div>
        </div>

        <p className="text-slate-300 mb-4 text-sm line-clamp-2">{event.description}</p>

        <div className="space-y-2 mb-4 text-sm text-slate-400">
          <p>
            📅 {formatDate(event.eventDate)} at {event.eventTime}
          </p>
          {event.location && <p>📍 {event.location}</p>}
          {event.capacity > 0 && (
            <p>
              👥 {event.registeredCount}/{event.capacity} registered
            </p>
          )}
        </div>

        {event.registrationLink && isUpcoming && (
          <Link href={event.registrationLink} target="_blank" className="block">
            <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">Register Now</Button>
          </Link>
        )}
      </div>
    </Card>
  )
}
