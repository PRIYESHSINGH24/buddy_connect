"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

interface ProjectCardProps {
  project: {
    _id: string
    title: string
    description: string
    githubUrl: string
    liveUrl?: string
    technologies?: string
    teamSize?: string
    author: {
      name: string
      college: string
      department: string
    }
    createdAt: string
    likes: number
  }
}

export function ProjectCard({ project }: ProjectCardProps) {
  const getTechTags = (tech: string) => {
    return (
      tech
        ?.split(",")
        .map((t) => t.trim())
        .filter(Boolean) || []
    )
  }

  return (
    <Card className="bg-slate-800 border-slate-700 p-6 hover:border-blue-600 transition">
      <div className="flex justify-between items-start mb-4">
        <div className="flex-1">
          <h3 className="text-xl font-bold text-white mb-1">{project.title}</h3>
          <p className="text-slate-400 text-sm">
            by <span className="text-blue-400">{project.author.name}</span> • {project.author.department}
          </p>
        </div>
        <span className="px-3 py-1 bg-blue-600/20 text-blue-400 text-xs rounded-full">{project.likes} likes</span>
      </div>

      <p className="text-slate-300 mb-4 line-clamp-3">{project.description}</p>

      {getTechTags(project.technologies).length > 0 && (
        <div className="mb-4">
          <div className="flex flex-wrap gap-2">
            {getTechTags(project.technologies)
              .slice(0, 5)
              .map((tech) => (
                <span key={tech} className="px-2 py-1 bg-slate-700 text-slate-300 text-xs rounded">
                  {tech}
                </span>
              ))}
            {getTechTags(project.technologies).length > 5 && (
              <span className="px-2 py-1 bg-slate-700 text-slate-300 text-xs rounded">
                +{getTechTags(project.technologies).length - 5}
              </span>
            )}
          </div>
        </div>
      )}

      {project.teamSize && <p className="text-slate-400 text-xs mb-4">👥 {project.teamSize} team</p>}

      <div className="flex gap-2">
        <Link href={project.githubUrl} target="_blank" className="flex-1">
          <Button className="w-full bg-slate-700 hover:bg-slate-600 text-white">View on GitHub</Button>
        </Link>
        {project.liveUrl && (
          <Link href={project.liveUrl} target="_blank" className="flex-1">
            <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">Live Demo</Button>
          </Link>
        )}
      </div>
    </Card>
  )
}
